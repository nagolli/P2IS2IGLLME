/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package P4;

/**
 *
 * @author Ignacio
 */
public class main
{
    public static void main(String[] args)
    {
        Contenedor c= new Contenedor(1,1);
        Contenedor2 d= new Contenedor2(1,1);
        HistoricoContenedores h= new HistoricoContenedores();
    }
}
